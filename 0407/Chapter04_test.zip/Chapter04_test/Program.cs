﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter04_test
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 10; j > i; j--)
                {
                    Console.Write(" ");
                }
                for (int k = 0; k < (2 * i) + 1; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            for (int i = 10; i > 0; i--)
            {
                for (int j = 10; j > i; j--)
                {
                    Console.Write(" ");
                }
                for (int k = 0; k < (2 * i) + 1; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            int maxvalue = 0;
            int minvalue = 0;
            int[] number1 = new int[5];



            Console.WriteLine("5개의 숫자를 입력해주세요.");


            for (int i = 0; i < 5; i++)
            {
                number1[i] = int.Parse(Console.ReadLine());
            }
            for (int j = 0; j < 5; j++)
            {
                if (number1[j] > maxvalue)
                {
                    maxvalue = number1[j];
                }
            }

            minvalue = number1[0];

            for (int i = 0; i < 5; i++)
            {
                if (number1[i] < minvalue)
                {
                    minvalue = number1[i];
                }
            }
            Console.WriteLine("최대값은 :" + maxvalue + "입니다");
            Console.WriteLine("최소값은 :" + minvalue + "입니다");
        }
    }
}
